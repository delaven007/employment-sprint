def fun(a:int,b:float) -> int:
    print(a,b)
    return a

fun("abc",1)



