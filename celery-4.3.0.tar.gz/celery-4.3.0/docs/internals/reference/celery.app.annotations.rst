==========================================
 ``celery.app.annotations``
==========================================

.. contents::
    :local:
.. currentmodule:: celery.app.annotations

.. automodule:: celery.app.annotations
    :members:
    :undoc-members:
