=======================================================
 ``celery.contrib.abortable``
=======================================================

.. contents::
    :local:

.. currentmodule:: celery.contrib.abortable

.. automodule:: celery.contrib.abortable
    :members:
    :undoc-members:
