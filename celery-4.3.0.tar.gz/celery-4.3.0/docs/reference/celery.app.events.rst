================================
 ``celery.app.events``
================================

.. contents::
    :local:
.. currentmodule:: celery.app.events

.. automodule:: celery.app.events
    :members:
    :undoc-members:
