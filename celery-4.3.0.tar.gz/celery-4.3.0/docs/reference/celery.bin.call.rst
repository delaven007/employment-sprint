=====================================================
 ``celery.bin.call``
=====================================================

.. contents::
    :local:
.. currentmodule:: celery.bin.call

.. automodule:: celery.bin.call
    :members:
    :undoc-members:
