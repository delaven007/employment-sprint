====================================================
 ``celery.app.control``
====================================================

.. contents::
    :local:
.. currentmodule:: celery.app.control

.. automodule:: celery.app.control
    :members:
    :undoc-members:
