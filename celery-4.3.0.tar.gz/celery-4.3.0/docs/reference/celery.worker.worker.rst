====================================
 ``celery.worker.worker``
====================================

.. contents::
    :local:
.. currentmodule:: celery.worker.worker

.. automodule:: celery.worker.worker
    :members:
    :undoc-members:
